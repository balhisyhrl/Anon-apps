<!-- sub menu -->
<div id="home-sidebar" class="sidebar-panel is-generic">
    <div class="subpanel-header">
        <h3 class="no-mb">HOME</h3>
        <div class="panel-close">
            <i data-feather="x"></i>
        </div>
    </div>
    <div class="inner" data-simplebar>
        <ul>

        </ul>
    </div>
</div>
<div class="mobile-subsidebar">
    <div class="inner">
        <div class="sidebar-title">
            <h3>HOME</h3>
        </div>

        <ul class="submenu">

        </ul>

    </div>
</div>
<!-- sub menu -->