<script>
    <?php if ($this->session->flashdata('success')) { ?>
        toastvelixs.success("<?= $this->session->flashdata('success') ?>")
    <?php } else if ($this->session->flashdata('error')) { ?>
        toastvelixs.error("<?= $this->session->flashdata('error') ?>")
    <?php } ?>
</script>